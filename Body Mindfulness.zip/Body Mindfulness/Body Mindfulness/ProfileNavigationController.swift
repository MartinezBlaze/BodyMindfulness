//
//  ProfileNavigationController.swift
//  Body Mindfulness
//
//  Created by Martin Christian on 18/05/19.
//  Copyright © 2019 Martin Christian. All rights reserved.
//

import Foundation
import UIKit

class ProfileNavigationController: UINavigationController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
